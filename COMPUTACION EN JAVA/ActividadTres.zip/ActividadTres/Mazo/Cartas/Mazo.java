package Cartas;

import java.io.*;

public class Mazo {

	private static BufferedReader datoCaptura = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) {
    	System.out.println("\n\n\n\n");
        System.out.println("         **Jugar**               ");
        Deck.CargaDatosInicio();
        Deck.RealizaAccionesActividad();
        System.out.println("   **   Fin de la partida   **   ");
        System.out.print("Presione ENTER para continuar.");
        System.out.println("\n\n");
        try {
			datoCaptura.readLine().toString().trim().toUpperCase();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
    
}
