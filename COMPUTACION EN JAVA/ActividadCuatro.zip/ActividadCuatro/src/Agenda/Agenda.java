package Agenda;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Agenda {

	private static BufferedReader datoCaptura = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String[] args) {
    	 System.out.println("\n\n\n\n");
         System.out.println("   Agenda Telefonica  \n");
         AddressBook.MenuAgenda();
         System.out.println("   Salir   ");
         System.out.print("Presione ENTER para cerrar aplicacion.");
         System.out.println("\n\n");
         try {
			datoCaptura.readLine().toString().trim().toUpperCase();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
    }
    
}
