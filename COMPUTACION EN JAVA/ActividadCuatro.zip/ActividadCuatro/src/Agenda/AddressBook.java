package Agenda;

import javax.management.InvalidApplicationException;
import java.io.*;
import java.util.*;

public class AddressBook {

	private static Map<String, String> MemoTels = null;
	private static BufferedReader datoCapturB = new BufferedReader(new InputStreamReader(System.in));
	
	private static String ArchivoProcesar = "src/Agenda/MemoTels.txt";
	
	public static void MenuAgenda() {
		String sOpcionCol = "";
		boolean bolSigeEvidencia = true;
		try {
			load();
			do {
				System.out.println("\n");
				System.out.println("A continuacion elige una opcion: \n");
				System.out.println("1.- Lista de contactos");
				System.out.println("2.- Nuevo Contacto");
				System.out.println("3.- Eliminar contaco");
				System.out.println("4.- Regresar al menu principal \n");
				System.out.println("Favor de especificar la opcion deseada");
				
				sOpcionCol = datoCapturB.readLine().toString().trim().toUpperCase();
				
				switch (sOpcionCol) {
				case "1":
					list();
					break;
				case "2":
					create();
					break;
				case "3":
					delete();
					break;
				case "4":
					bolSigeEvidencia = false;
					break;
				default:
					System.out.println("");
					System.out.println("Dato incorrecto, introduce un dato valido");
					System.out.println("");
					MenuAgenda();
					break;
					
				}
				sOpcionCol = "";
			} while (bolSigeEvidencia);
		} catch (Exception ex) {
			System.out.println(" Error " + ex.getMessage());
		} finally {
			
		}
	}
	
	 private static void list(){
		 try {
			 System.out.println("\n\n\nContactos:");
			 for (Map.Entry<String, String> item : MemoTels.entrySet()) {
				 System.out.println("         " + item.getKey() + ", " + item.getValue());
			 }
			 System.out.print("\n\nPreciona ENTER para continuar. ");
			 datoCapturB.readLine();
		 }
		 catch (Exception ex) {
			 System.out.println(" Error " + ex.getMessage());
		 }
		 finally {}
	 }
	private static void create() {
		String nTelefono = "";
		String Nombre = "";
		try {
			System.out.println("\n                     Nuevo contacto\n");
			
			nTelefono = SolicitaTelefono();
			System.out.print("Captura un nombre:");
			Nombre = datoCapturB.readLine().toString().trim();
			
			MemoTels.put(nTelefono, Nombre);
			
			save();
			System.out.print("\n\nGuardado correctamente. Preciona ENTER para continuar. ");
			datoCapturB.readLine();
		}
		catch (Exception ex) {
			System.out.println(" Error " + ex.getMessage());
		}
		finally {}
		
	}
	
	private static void delete() {
		String xTelefonoEliminar = "";
		String xAccion = "";
		try {
			System.out.println("\n                     Eliminar contacto. \n");
			xTelefonoEliminar = SolicitaTelefono();
			
			if (ValidaTelefono(xTelefonoEliminar)) {
				MemoTels.remove(xTelefonoEliminar);
				System.out.print("\nEliminado correctamente. Preciona ENTER para continuar. ");
				datoCapturB.readLine();
			}
			else {
				System.out.print("\nEl Tel�fono ingresado no existe digita x/X para salir u otro car�cter para reintentar: ");
				xAccion = datoCapturB.readLine().toString().trim().toUpperCase();
				switch (xAccion) {
				case "X":
					break;
				default:
					delete();
					break;
				}
			}
		}
		catch (Exception ex) {
			System.out.print(" Error " + ex.getMessage());
		}
		finally {}
	}
	
	private static void load() {
		BufferedReader brAgenda = null;
		String xLinea;
		try {
			MemoTels = new HashMap<>();
			brAgenda = new BufferedReader(new FileReader(ArchivoProcesar));
			
			while ((xLinea = brAgenda.readLine()) != null) {
				String[] xDato = null;
			    if (xLinea != "") { 
			    	xDato = xLinea.split(",");
			    	MemoTels.put(xDato[0].trim(), xDato[1].trim());
			    }
			}
		}
		catch (Exception ex) {
			System.out.print(" Error " + ex.getMessage());
		}
		finally {
			try {
				if (brAgenda != null) brAgenda.close();
			}
			catch (IOException ex) {System.out.println(" Error " + ex.getMessage());}
		}
	}	
	private static void save() {
		BufferedWriter bwAgenda = null;
		String xLinea;
		try {
			bwAgenda = new BufferedWriter(new FileWriter(ArchivoProcesar));
			for (Map.Entry<String, String> item : MemoTels.entrySet()) {
				bwAgenda.write(item.getKey() + "," + item.getValue() + "\n");
			}
		}
		catch (Exception ex) {
			System.out.println(" Error " + ex.getMessage());
		}
		finally {
			try {
				if (bwAgenda != null) bwAgenda.close();
			    }
			catch (IOException ex) { System.out.println(" Error " + ex.getMessage());}
		}
	}
	
	private static String SolicitaTelefono() {
		String Result = "";
		try {
			System.out.print("Captura un numero");
			Result = datoCapturB.readLine().toString().trim();
			
			Long.parseLong(Result);
			if (Result.length() != 10) throw new InvalidApplicationException("Numero incorrecto");
			
		}
		catch (NumberFormatException nfe) { 
			System.out.println("Longitud de numero invalida, digita maximo 10 caracteres");
			Result = SolicitaTelefono();
		}
		catch (InvalidApplicationException ex) {
			System.out.println("Longitud de numero invalida, digita maximo 10 caracteres");
			Result = SolicitaTelefono();
		}
		catch (Exception ex) { 
			System.out.println(" Error " + ex.getMessage());
		}
		finally {}
		return Result;
	}
	
	private static Boolean ValidaTelefono(String xTelefono) {
		Boolean Result = false;
		for (Map.Entry<String, String> item : MemoTels.entrySet()) {
			if (item.getKey().equals(xTelefono));{
			Result = true;
			break;
		}
	 }
	return Result;
  }	
}
